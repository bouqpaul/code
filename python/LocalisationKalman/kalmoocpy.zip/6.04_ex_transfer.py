from roblib import *
M = array([[1,2],[3,4]])
print(M)