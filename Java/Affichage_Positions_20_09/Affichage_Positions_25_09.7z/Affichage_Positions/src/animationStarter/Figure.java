package animationStarter;
import java.util.*;
import java.awt.*;

public abstract class Figure extends Trajectoire {
	
	public void display(Graphics2D g2){}
}
